java -cp ../lib/derby.jar:../lib/derbyclient.jar:../dist/BenchmarkSQL-2.3.jar -Dprop=$1 LoadData $2 $3 $4 $5
